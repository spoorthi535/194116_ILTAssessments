package com.nttdata;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client {
	public static void main(String[] args){
	
	
	Configuration cfg=new Configuration();
	cfg.configure("HibernateConfig.xml");
	
	SessionFactory fc=cfg.buildSessionFactory();
	Session session=fc.openSession();
	Query query=session.createSQLQuery("CALL studentData()").addEntity(Student.class);
	List<Student> list=query.list();
	for(Student s:list)
	{
		System.out.println(s);
	}
	
	Student s=new Student();
	s.setSid(123);
	s.setSname("Sheethal");
	s.setSaddress("Bangalore");
	
	Transaction tx=session.beginTransaction();
	//session.save(s);
	tx.commit();
	session.close();
	fc.close();
	}
}