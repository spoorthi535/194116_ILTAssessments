package com.nttdata;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;
public class Client {
	 
public static void main(String args[]) {
	
    List<Employee> empList = new ArrayList<>();
    empList.add(new Employee("spoorthi",20,20000));
    empList.add(new Employee("vani",12, 16000));
    empList.add(new Employee("sheethal",15, 2500));
    empList.add(new Employee("chandana",16, 10000));

    
    empList.stream().filter(emp->emp.getSalary() > 10000).forEach(System.out::println);
    long i=empList.stream().filter(emp->emp.getSalary()>10000).count();
    System.out.println("count of employees whose salary is greater than 10000 is="+i);
}
		    
		    
		    
	}