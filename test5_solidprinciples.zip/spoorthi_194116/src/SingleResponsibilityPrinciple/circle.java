package SingleResponsibilityPrinciple;

public class circle {
	
double calcArea(double rad){
	return (Math.PI*radius*radius);
}
}
