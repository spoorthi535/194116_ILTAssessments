package DependencyInversion;

public interface ICustomerDataAccess {
	String GetCustomerName(int id);
}
