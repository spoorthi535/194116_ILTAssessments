package InterfaceSegregation;

public interface PenDrive {
public void SupportPenDrive();

}
