package com.nttdata;

import java.util.Scanner;



public class Client {
	public static void main(String args[]){
		Scanner input=new Scanner(System.in);
		int selection;
		Scanner sc=new Scanner(System.in);
		Account acc1=new Account();
    	User u1=new User();
    	Account acc2=new Account();
    	User u2=new User();
    	Bank b=new Bank();
		do{
		System.out.println("WELCOME TO BANK APPLICATION");
		System.out.println("Press numbers for more details :");
		System.out.println("1. Create Account "+"\t"+ "2. Transfer Funds "+"\t"+"3. Quit");
		//Scanner input=new Scanner(System.in);
		selection = input.nextInt();
		switch(selection){
		   
    	case 1:
    	
    		{
       		
       		int in;
			do{
       		System.out.println("1.To create account"+"\t"+ "2. To repeat account creation"+"\t"+"3. quit");
       		 in = input.nextInt();
       		switch(in)
       		{
       		case 1:
    	    {  
    	    	
    	    	
    			System.out.println("enter the Account ID");
    			int id1=sc.nextInt();
    			acc1.setAccId(id1);
    			System.out.println("enter the amount");
    			double amount1=sc.nextDouble();
    			acc1.setAmount(amount1);
    			
    			System.out.println("enter the 1st User name");
    			String name1=sc.next();
    			u1.setUserName(name1);
    			//System.out.println("enter the Account");
    			
    			u1.setAcc(acc1);
    	    	  break;
    	    }  

       		case 2:
    	    {  
    	    	
    	    	
    			System.out.println("enter the Account ID");
    			int id2=sc.nextInt();
    			acc2.setAccId(id2);
    			System.out.println("enter the amount");
    			double amount2=sc.nextDouble();
    			acc2.setAmount(amount2);
    			
    			System.out.println("enter the 2nd User name");
    			String name2=sc.next();
    			u2.setUserName(name2);
    			//System.out.println("enter the Account");
    			
    			u2.setAcc(acc2);
    	    	  break;
    	    }  
    case 3:in=3;
    
       		}
      
		}while(in!=3);
    		}	
    	break;

    	case 2:
        	
		{
   		
   		int in1;
		do{
   		System.out.println("1.Transfer amount from u1 to u2"+"\t"+ "2. Transfer amount from u2 to u1"+"\t"+"3. quit");
   		 in1 = input.nextInt();
   		switch(in1)
   		{
   		case 1:
	    {  
	    	System.out.println("enter the amount for transaction");
	    	double amtount=sc.nextDouble();
	    	//acc1.setAmount(amt1);
	    	System.out.println("before transaction both user details");
	    	System.out.println("user1 Name "+u1.getUserName()+"\t"+"Account ID "+u1.getAcc().getAccId()+"\t"+"user1 Account Amount "+u1.getAcc().getAmount());
	    	System.out.println("user2 Name "+u2.getUserName()+"\t"+"Account ID "+u2.getAcc().getAccId()+"\t"+"user2 Account Amount "+u1.getAcc().getAmount());
	    	
	    	try{
	    	b.transferFunds(u1, u2, amtount);
	    	}
	    	catch(InsufficientAmount e){
	    		e.printStackTrace();
	    	}
	    	  break;
	    }  

   		case 2:
	    {  
	    	System.out.println("enter the amount for transaction");
	    	double amount=sc.nextDouble();
	    	//acc1.setAmount(amt2);
	    	System.out.println("After transaction both user details");
	    	System.out.println("user1 Name "+u1.getUserName()+"\t"+"Account ID "+u1.getAcc().getAccId()+"\t"+"user1 Account Amount "+u1.getAcc().getAmount());
	    	System.out.println("user2 Name "+u2.getUserName()+"\t"+"Account ID "+u2.getAcc().getAccId()+"\t"+"user2 Account Amount "+u1.getAcc().getAmount());
	    	
	    	try{
	    	b.transferFunds(u2, u1, amount);
	    	}
	    	catch(InsufficientAmount e){
	    		e.printStackTrace();
	    	}	
	    	  break;
	    }  
case 3:in1=3;

   		}
  
	}while(in1!=3);
		}	
	break;

	
    	
    	case 4:System.exit(0);
   	 }
   	
   	 
	}while(selection!=4);
}
}
