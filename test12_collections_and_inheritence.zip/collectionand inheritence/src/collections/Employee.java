package com.nttdata;

public class Employee {
	private int empId;
    private String name;
    private int salary;
    private String address;
    private String grade;
    private int mobileno;
    private String email;
    
    
    
 
    public Employee(int empId, String name, int salary, String address,String grade,int mobileno,String email) {
        this.empId = empId;
        this.name = name;
        this.salary = salary;
        this.address = address;
        this.grade = grade;
        this.mobileno = mobileno;
        this.email = email;
    }




	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", salary=" + salary + ", address=" + address
				+ ", grade=" + grade + ", mobileno=" + mobileno + ", email=" + email + "]";
	}
 
 
}



