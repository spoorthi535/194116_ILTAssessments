package com.nttdata;

import java.util.ArrayList;

public class Client {
	public static void main(String args[]) {
        // Creating user-defined class objects
        Employee emp1 = new Employee(101, "spoorthi",2000,"bangalore","A",562107,"spoo@123");
        Employee emp2 = new Employee(102, "Monika",6000,"kolar","B",5644507,"mou@123");
        Employee emp3 = new Employee(103, "sheethal",5000,"mysore","A+",5623007,"shee@123");
        
 
        ArrayList<Employee> list = new ArrayList<Employee>();
        list.add(emp1);
        list.add(emp2);
        list.add(emp3);
 
        for (Employee emp : list)
            System.out.println(emp);
    }
}