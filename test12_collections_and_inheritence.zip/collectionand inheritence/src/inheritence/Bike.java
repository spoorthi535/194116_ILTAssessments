package Vehicles;

import java.util.Scanner;

public class Bike extends Vehicle {
	public void bikeinfo()
	{
		 
		 System.out.println("Number: ");
		 Scanner input=new Scanner(System.in);
		 int number = input.nextInt();
		 System.out.println("Name: ");
		 String name = input.next();
		 System.out.println("price ");
		 int price= input.nextInt();
		 System.out.println("color: ");
		 String color = input.next();
		 
		 System.out.println("NUMBER:"+number+"NAME:"+name+"PRICE:"+price+"COLOR:"+color);	 
	}	 
		 
	void status(String in)

	{
	switch(in)
	{
	case "1":
		    {  
		    	  System.out.println("STARTED"); 
		    	  break;
		    }  

	case "2":
		    {  
		    	  System.out.println("STOPPED"); 
		    	  break;
		    }  

	case "q":
		    {  
		    	  System.exit(0); 
		    	  break;
		    }  
		}  
	}}