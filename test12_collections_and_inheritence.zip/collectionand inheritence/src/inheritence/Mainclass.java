package Vehicles;

import java.util.Scanner;

public class Mainclass {

	public static void main(String[] args) {
		
           System.out.println("WELCOME TO VEHICLE SIMULATION");
           System.out.println("Press numbers for more details :");
           System.out.println("1. CAR"+"\t"+ "2. BIKE"+"\t"+"3. BUS");
           Scanner input=new Scanner(System.in);
          int selection = input.nextInt();
while(true)
{
   switch(selection){
   
        case 1:
        {
           
           Car c= new Car();
           System.out.println("CAR DETAILS:"); 
           
           c.carinfo();
           System.out.println("1. Start car"+"\t"+ "2. Stop car"+"\t"+"3. quit");
           String in = input.next();
           c.status(in);
           break;
   }

        case 2:
        {
        	
        
           System.out.println("BIKE DETAILS:"); 
           Bike b = new Bike();
           b.bikeinfo();
           System.out.println("1. Start bike"+"\t"+ "2. Stop bike"+"\t"+"3. quit");
           String in = input.next();
           b.status(in);
           break;
        }

        case 3:
        {
           System.out.println("BUS DETAILS:");
           Bus b1=new Bus();
           b1.businfo();
           System.out.println("1. Start bus"+"\t"+ "2. Stop bus1"+"\t"+"3. quit");
           String in = input.next();
           b1.status(in);
           break;
        
      }
   }
   
}
	}

}