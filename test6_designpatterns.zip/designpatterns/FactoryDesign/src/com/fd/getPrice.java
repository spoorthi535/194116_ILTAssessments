package com.fd;

public class getPrice {

	public Mobile getPrice(String mobileBrand) {
		
		if(mobileBrand.equalsIgnoreCase("htc")) {
			return new htc();
		}
		
		if(mobileBrand.equalsIgnoreCase("oneplus")) {
			return new oneplus();
		}
		
		if(mobileBrand.equalsIgnoreCase("motog")) {
			return new mptog();
		}
		
		if(mobileBrand==null) {
			return null;
		}
	return null;
	}
}
