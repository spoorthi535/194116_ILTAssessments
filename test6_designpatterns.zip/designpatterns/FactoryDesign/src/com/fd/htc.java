package com.fd;

public class htc extends Mobile {

	@Override
	public double getTax() {
		return 24.00;
		
	}

}
